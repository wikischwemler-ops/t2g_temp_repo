/*******************************************************************************
 * File Name: cycfg_clocks.h
 *
 * Description:
 * Peripheral clock divider configuration
 * This file was automatically generated and should not be modified.
 * Configurator Backend 3.90.0
 * device-db 4.40.0.11123
 * mtb-pdl-cat1 3.24.0.47219
 *
 *******************************************************************************
 * Copyright 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#if !defined(CYCFG_CLOCKS_H)
#define CYCFG_CLOCKS_H

#include "cycfg_notices.h"
#include "cy_sysclk.h"

#if defined (CY_USING_HAL)
#include "cyhal_hwmgr.h"
#endif /* defined (CY_USING_HAL) */

#if defined(__cplusplus)
extern "C" {
#endif /* defined(__cplusplus) */

#define CYBSP_TRACE_CLK_DIV_ENABLED 1U

#if defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE)
#define CYBSP_TRACE_CLK_DIV_HW CYHAL_CLOCK_BLOCK_PERIPHERAL0_8BIT
#endif /* defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE) */

#if !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE)
#define CYBSP_TRACE_CLK_DIV_HW CY_SYSCLK_DIV_8_BIT
#endif /* !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE) */

#define CYBSP_TRACE_CLK_DIV_NUM 3U
#define CYBSP_TRACE_CLK_DIV_GRP_NUM ((0U << PERI_PCLK_GR_NUM_Pos) | (0U << PERI_PCLK_INST_NUM_Pos))

#if !defined (CYBSP_TRACE_CLK_DIV_GRP_NUM)
#define CYBSP_TRACE_CLK_DIV_GRP_NUM CYBSP_TRACE_CLK_DIV_GRP_NUM
#endif /* !defined (CYBSP_TRACE_CLK_DIV_GRP_NUM) */

#define peri_0_group_0_div_16_0_ENABLED 1U

#if defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE)
#define peri_0_group_0_div_16_0_HW CYHAL_CLOCK_BLOCK_PERIPHERAL0_16BIT
#endif /* defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE) */

#if !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE)
#define peri_0_group_0_div_16_0_HW CY_SYSCLK_DIV_16_BIT
#endif /* !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE) */

#define peri_0_group_0_div_16_0_NUM 0U
#define PERI_0_GROUP_0_DIV_16_0_GRP_NUM ((0U << PERI_PCLK_GR_NUM_Pos) | (0U << PERI_PCLK_INST_NUM_Pos))

#if !defined (peri_0_group_0_div_16_0_GRP_NUM)
#define peri_0_group_0_div_16_0_GRP_NUM PERI_0_GROUP_0_DIV_16_0_GRP_NUM
#endif /* !defined (peri_0_group_0_div_16_0_GRP_NUM) */

#define peri_0_group_0_div_16_2_ENABLED 1U

#if defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE)
#define peri_0_group_0_div_16_2_HW CYHAL_CLOCK_BLOCK_PERIPHERAL0_16BIT
#endif /* defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE) */

#if !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE)
#define peri_0_group_0_div_16_2_HW CY_SYSCLK_DIV_16_BIT
#endif /* !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE) */

#define peri_0_group_0_div_16_2_NUM 2U
#define PERI_0_GROUP_0_DIV_16_2_GRP_NUM ((0U << PERI_PCLK_GR_NUM_Pos) | (0U << PERI_PCLK_INST_NUM_Pos))

#if !defined (peri_0_group_0_div_16_2_GRP_NUM)
#define peri_0_group_0_div_16_2_GRP_NUM PERI_0_GROUP_0_DIV_16_2_GRP_NUM
#endif /* !defined (peri_0_group_0_div_16_2_GRP_NUM) */

#define peri_0_group_1_div_8_0_ENABLED 1U

#if defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE)
#define peri_0_group_1_div_8_0_HW CYHAL_CLOCK_BLOCK_PERIPHERAL1_8BIT
#endif /* defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE) */

#if !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE)
#define peri_0_group_1_div_8_0_HW CY_SYSCLK_DIV_8_BIT
#endif /* !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE) */

#define peri_0_group_1_div_8_0_NUM 0U
#define PERI_0_GROUP_1_DIV_8_0_GRP_NUM ((1U << PERI_PCLK_GR_NUM_Pos) | (0U << PERI_PCLK_INST_NUM_Pos))

#if !defined (peri_0_group_1_div_8_0_GRP_NUM)
#define peri_0_group_1_div_8_0_GRP_NUM PERI_0_GROUP_1_DIV_8_0_GRP_NUM
#endif /* !defined (peri_0_group_1_div_8_0_GRP_NUM) */

#define peri_0_group_1_div_24_5_0_ENABLED 1U

#if defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE)
#define peri_0_group_1_div_24_5_0_HW CYHAL_CLOCK_BLOCK_PERIPHERAL1_24_5BIT
#endif /* defined (CY_USING_HAL) || defined (CY_USING_HAL_LITE) */

#if !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE)
#define peri_0_group_1_div_24_5_0_HW CY_SYSCLK_DIV_24_5_BIT
#endif /* !defined (CY_USING_HAL) && !defined (CY_USING_HAL_LITE) */

#define peri_0_group_1_div_24_5_0_NUM 0U
#define PERI_0_GROUP_1_DIV_24_5_0_GRP_NUM ((1U << PERI_PCLK_GR_NUM_Pos) | (0U << PERI_PCLK_INST_NUM_Pos))

#if !defined (peri_0_group_1_div_24_5_0_GRP_NUM)
#define peri_0_group_1_div_24_5_0_GRP_NUM PERI_0_GROUP_1_DIV_24_5_0_GRP_NUM
#endif /* !defined (peri_0_group_1_div_24_5_0_GRP_NUM) */

#if defined (CY_USING_HAL)
extern const cyhal_resource_inst_t CYBSP_TRACE_CLK_DIV_obj;
extern const cyhal_resource_inst_t peri_0_group_0_div_16_0_obj;
extern const cyhal_resource_inst_t peri_0_group_0_div_16_2_obj;
extern const cyhal_resource_inst_t peri_0_group_1_div_8_0_obj;
extern const cyhal_resource_inst_t peri_0_group_1_div_24_5_0_obj;
#endif /* defined (CY_USING_HAL) */

void init_cycfg_clocks(void);
void reserve_cycfg_clocks(void);

#if defined(__cplusplus)
}
#endif /* defined(__cplusplus) */

#endif /* CYCFG_CLOCKS_H */
