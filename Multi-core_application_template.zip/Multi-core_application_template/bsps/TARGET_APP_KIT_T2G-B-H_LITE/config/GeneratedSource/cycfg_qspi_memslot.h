/*******************************************************************************
 * File Name: cycfg_qspi_memslot.h
 *
 * Description:
 * Provides declarations of the SMIF-driver memory configuration.
 * This file was automatically generated and should not be modified.
 * QSPI Configurator 4.90.0.3032
 *
 *******************************************************************************
 * Copyright 2026, Infineon Technologies AG, or an affiliate of Infineon
 * Technologies AG. All rights reserved.
 * SPDX-License-Identifier: Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ******************************************************************************/

#ifndef CYCFG_QSPI_MEMSLOT_H
#define CYCFG_QSPI_MEMSLOT_H
#include "cy_smif_memslot.h"

#define CY_SMIF_CFG_TOOL_VERSION           (490)

/* Supported QSPI Driver version */
#define CY_SMIF_DRV_VERSION_REQUIRED       (100)

#if !defined(CY_SMIF_DRV_VERSION)
    #define CY_SMIF_DRV_VERSION            (100)
#endif

/* Check the used Driver version */
#if (CY_SMIF_DRV_VERSION_REQUIRED > CY_SMIF_DRV_VERSION)
   #error The QSPI Configurator requires a newer version of the PDL. Update the PDL in your project.
#endif

typedef cy_stc_smif_mem_config_t cy_serial_flash_mem_config_t;
typedef cy_stc_smif_block_config_t cy_serial_flash_block_config_t;

#define CY_SMIF_DEVICE_NUM 1

extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_writeEnCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_writeDisCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_eraseCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_chipEraseCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_programCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readStsRegQeCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readStsRegWipCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_writeStsRegQeCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readStsRegOeCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_writeStsRegOeCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readLatencyCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_writeLatencyCmd;
extern cy_stc_smif_mem_cmd_t SFDP_SlaveSlot_0_readSfdpCmd;

extern cy_stc_smif_mem_device_cfg_t deviceCfg_SFDP_SlaveSlot_0;

extern cy_stc_smif_mem_config_t SFDP_SlaveSlot_0;

#define Auto_detect_SFDP_SlaveSlot_0_readCmd SFDP_SlaveSlot_0_readCmd
#define Auto_detect_SFDP_SlaveSlot_0_writeEnCmd SFDP_SlaveSlot_0_writeEnCmd
#define Auto_detect_SFDP_SlaveSlot_0_writeDisCmd SFDP_SlaveSlot_0_writeDisCmd
#define Auto_detect_SFDP_SlaveSlot_0_eraseCmd SFDP_SlaveSlot_0_eraseCmd
#define Auto_detect_SFDP_SlaveSlot_0_chipEraseCmd SFDP_SlaveSlot_0_chipEraseCmd
#define Auto_detect_SFDP_SlaveSlot_0_programCmd SFDP_SlaveSlot_0_programCmd
#define Auto_detect_SFDP_SlaveSlot_0_readStsRegQeCmd SFDP_SlaveSlot_0_readStsRegQeCmd
#define Auto_detect_SFDP_SlaveSlot_0_readStsRegWipCmd SFDP_SlaveSlot_0_readStsRegWipCmd
#define Auto_detect_SFDP_SlaveSlot_0_writeStsRegQeCmd SFDP_SlaveSlot_0_writeStsRegQeCmd
#define Auto_detect_SFDP_SlaveSlot_0_readStsRegOeCmd SFDP_SlaveSlot_0_readStsRegOeCmd
#define Auto_detect_SFDP_SlaveSlot_0_writeStsRegOeCmd SFDP_SlaveSlot_0_writeStsRegOeCmd
#define Auto_detect_SFDP_SlaveSlot_0_readLatencyCmd SFDP_SlaveSlot_0_readLatencyCmd
#define Auto_detect_SFDP_SlaveSlot_0_writeLatencyCmd SFDP_SlaveSlot_0_writeLatencyCmd
#define Auto_detect_SFDP_SlaveSlot_0_readSfdpCmd SFDP_SlaveSlot_0_readSfdpCmd
#define deviceCfg_Auto_detect_SFDP_SlaveSlot_0 deviceCfg_SFDP_SlaveSlot_0
#define Auto_detect_SFDP_SlaveSlot_0 SFDP_SlaveSlot_0

extern cy_stc_smif_mem_config_t* smifMemConfigs[CY_SMIF_DEVICE_NUM];

extern cy_stc_smif_block_config_t smifBlockConfig;


#endif /*CYCFG_QSPI_MEMSLOT_H*/
